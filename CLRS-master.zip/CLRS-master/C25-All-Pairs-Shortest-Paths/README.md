UNSOLVED

[25.1.4](./25.1.md#exercises-251-4)
[25.1.5](./25.1.md#exercises-251-5)

[25.2.3](./25.2.md#exercises-252-3)
[25.2.9](./25.2.md#exercises-252-9)


