UNSOLVED

[32.2.4](./32.2.md#exercises-322-4)
[32.3.4](./32.3.md#exercises-323-4)
[32.4.6](./32.4.md#exercises-324-6)


